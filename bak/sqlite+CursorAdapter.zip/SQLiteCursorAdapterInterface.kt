package com.korneysoft.rsshcool2021_android_task_4_db.data.sqlite

import android.database.Cursor
import com.korneysoft.rsshcool2021_android_task_4_db.data.Item

interface SQLiteCursorAdapterInterface {
    fun getItem(cursor: Cursor): Item
    fun getCursor():Cursor
}